﻿namespace MVC.Models
{
    public class UserAzureAD
    {
        public required string user_name { get; set; }
        public required string user_domain { get; set; }
        public required string user_email { get; set; }
    }
}
