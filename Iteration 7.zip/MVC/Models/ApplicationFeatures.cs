﻿namespace MVC.Models
{
    public static class ApplicationFeatures
    {
        public const string FeatureA = "FeatureA";
        public const string FeatureB = "FeatureB";
        public const string FeatureC = "FeatureC";
    }
}
